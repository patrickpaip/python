import React, { Component } from 'react';
import {COUNTER_INCREMENT,COUNTER_DECREMENT, COUNTER_INCREMENT_BY, COUNTER_DECREMENT_BY, HISTORY_ADD, HISTORY_RESET} from '../../store/actions/actions'
import CounterControl from '../../components/CounterControl/CounterControl';
import CounterOutput from '../../components/CounterOutput/CounterOutput';
import {connect} from 'react-redux'
class Counter extends Component {
    render () {
        return (
            <div>
                <CounterOutput value={this.props.ctr} />
                <CounterControl label="Increment" clicked={this.props.onIncrement} />
                <CounterControl label="Decrement" clicked={this.props.onDecrement}  />
                <CounterControl label="Add 5" clicked={() => {this.props.onIncrementBy(5);this.props.addHistory(5)}}  />
                <CounterControl label="Subtract 5" clicked={() =>{ this.props.onDecrementBy(5);this.props.addHistory(-5)}}  />
                <CounterControl label="RESET" clicked={() => {this.props.resethistory()}} />
                 {
                    this.props.history.map((data)=>{
                    return <h1>{data}</h1>
                })
                }
            </div>
        );
    }
}

// Accessible as props inside your component
const mapStateToProps= state =>{
    return {
        ctr: state.counter.counter,
        history : state.history.history
    }
}
// Event Attached as Props
const mapDispatchToProps = dispatch =>{
    return {
        onIncrement : () => dispatch({type:COUNTER_INCREMENT}),
        onDecrement : () => dispatch({type:COUNTER_DECREMENT}),
        onIncrementBy : (by) => dispatch({type:COUNTER_INCREMENT_BY,payload:by}),
        onDecrementBy : (by) => dispatch({type:COUNTER_DECREMENT_BY,payload:by}),
        addHistory : (payload) => dispatch({type: HISTORY_ADD,payload:payload}),
        resethistory : () => dispatch({type: HISTORY_RESET})
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Counter);

