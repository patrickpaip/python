import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import { createStore, combineReducers } from 'redux'
import counterReducer  from './store/reducers/reducer';
import historyReducer  from './store/reducers/historyReducer';
import {Provider} from 'react-redux';

const rootReducer = combineReducers({
    history: historyReducer,
    counter : counterReducer
});


const store=createStore(rootReducer);
console.log('Current State',store.getState());
ReactDOM.render(<Provider store={store}><App /></Provider>, document.getElementById('root'));
registerServiceWorker();
