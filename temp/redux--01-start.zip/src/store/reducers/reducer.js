import {COUNTER_INCREMENT,COUNTER_DECREMENT,COUNTER_INCREMENT_BY, COUNTER_DECREMENT_BY} from '../actions/actions'

const initialState = {
    counter: 0,
    loaded: true
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case COUNTER_INCREMENT: {
            // Code Manipulation
            return {
                ...state,
                counter: state.counter += 1
            }
        }
        case COUNTER_DECREMENT: {
             // Code Manipulation
            return {
                ...state,
                counter: state.counter -= 1
            }
        }
        case COUNTER_INCREMENT_BY:{
                return {
                    ...state,
                    counter: state.counter+ action.payload
                }
            
        }
        case COUNTER_DECREMENT_BY:{
            return {
                ...state,
                counter: state.counter- action.payload
            }
        }
        default: {
            return state;
        }
    }
}

export default reducer;