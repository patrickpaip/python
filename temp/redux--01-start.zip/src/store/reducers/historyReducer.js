import { HISTORY_RESET, HISTORY_ADD } from '../actions/actions'

const initialState = {
    history: [1,2,3,4]
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case HISTORY_ADD: {
            return {
                history: [...state.history,action.payload]
            }
        }
        case HISTORY_RESET: {
            return {
                history:[]
            }
        }
        default: {
            return state;
        }
    }
}

export default reducer;