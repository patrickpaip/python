export const COUNTER_INCREMENT ='[Counter] INC';
export const COUNTER_DECREMENT ='[Counter] DEC';
export const COUNTER_INCREMENT_BY ='[Counter] INC_BY';
export const COUNTER_DECREMENT_BY ='[Counter] DEC_BY';


export const HISTORY_ADD ='[History] ADD';
export const HISTORY_RESET ='[History] RESET';