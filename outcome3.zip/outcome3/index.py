'''
a="Hello World"
print (a[0])
print (a[10])
print (a[-1]) # Python has Negative Index
# print (a[11]) # IndexError: string index out of range
print (len(a))
# a[0]='F'  # no support for item assignment
            # Note: Strings are immutable
'''

###### Splicing
'''
a="Hello World"
print (a[0:6])
print (a[6:-1])
print (a[:6])
print (a[6:])
print (a[::2]) # HloWrd
print (a[:]) # One of the Cloning Method (In Future)
print (a[::-1]) # Reverse a String
# Resultant is a new String
'''
'''
a=4
b=5
print (a==4)  
print (a>4)
print (a<4)
print (a>=4)
print (a<=4)
print (a!=4)

print (a==4 and a==5)
print (a is 4 and a is 5)
print (a==4 or a==5)
print (a is not 5 or b is 5)   #a!=5 and b==5
print (not a)  # !a
'''
'''
a="Hello"
b=" World"
d=4  
c=a+b+str(d)  # Str to Str is possible, not other combination with str
print(c)
'''

'''
# Restricted allowed assignments and solution
a=4
b="Hello World"
print (type(str))  # Defaults to Class Type
str=4  # local variable gets created and type is class int
del str # Delete the localvariable created
c=str(a)+b 
'''
'''
# Task1
a="Hello World"
# Manipulation
"FelloworlD"
c="F"+a[1:5]+"w"+a[7:-1]+"D"
print (c)
'''

# Conditional Statements
# a=4
# b=4
# if(a==4):
# 	print ("Its 4")
# 	print ("Yes its 4")
# 	if(b==4):
# 		print ("b is 4")
# print ("Hello World")

# # In C, convert to Python
# int a=4;
# if(a>5 && a<10){
# 	printf("A is within Limit");
# 	printf("Congrats");
# }
# else{
# 	printf("Outside the Limit");
# 	printf("Good Bye");
# }
'''
a=7
if(5<a<10):
	print("A is within Limit")
	print("Congrats")
	if(a is 7):
		print (a**3)
elif(a==4):
	print (" A is 4")
else:
	print("Outside the Limit");
	print("Good Bye");
'''

# Visit to Strings
'''
a="Hello World"
# The Comparison is case sensitive, use regex as alternative
if ('H' in a):
	print ("Exists")
else:
	print ("Nope")
# Complete Word Can be Compared
if ('Hello' in a):
	print ("Exists")
else:
	print ("Nope")
'''

# counter=0
# limit=100
# while(counter<limit):
# 	print(counter)
# 	counter+=1

'''
a="Hello World"
counter=0
while(counter<len(a)):
	print ("Index",counter,"Value",a[counter])
	# if(counter==5):
	# 	break  # Breaks the nearest Loop and skips else block
	counter+=1
else:  # only Executed Upon successful execution of while without breaking
	print ("I am Done") 
''' 

# Output:
# Index 0 Value H
# Index 1 Value e

a="Hello World"

# for x in range(100):
# 	print (x)

# for x in range(50,100):  # Lower Limit included
# 	print (x)

# for x in range(0,100,2):  # print at increments of 2
# 	print (x)

# Enumerate is applicable for datastructures having 
# index as integers
# for x,y in enumerate(a):
# 	print (x,y)

# x=4
# y=5
# print (x,y)
# x,y=y,x
# print (x,y)

# represented by []
# Can contain hetergenous datatypes
# Can extend to any size uptil RAM capacity
# Dont use it for long lists in Production!
list_a=[1,2,3,4,5,6]
# print (list_a[2])
# print (list_a[-1])
# print (len(list_a))
# # Splicing Operation
# print (list_a[0:2])
# print (list_a[2:])  # Gives back a new list
# #  Is Mutable
# list_a[0]=99
# print (list_a)

# for x in list_a:
# 	print (x)
# for x,y in enumerate(list_a):
# 	print (x,y)
# if ("Hello" in list_a):
# 	print ("Exist")

# list_c=[[1,[55,66,88],3],
#         [4,5,6],
#         [7,8,9]]
# print (list_c[0][1][-1])

'''
list_b=[5,6,7]
print (list_a)
list_a.append("Hello")
list_a.append(True)
list_a.append(list_b)
print (list_a)
list_a.insert(0,"NOON")
print (list_a)
list_a.insert(len(a),"WORKS!")
print (list_a)
list_a.remove("NOON") # Remove by Value
print (list_a)
del list_a[0]   # Remove By Index
print (list_a)
# list_a.clear()
# print (list_a)
'''

# list_a=[1,2,3]
# list_b=[4,5,6]
# list_a.append(list_b)
# print (list_a)
# list_b[0]=99
# print (list_b)
# print (list_a)

# name         			address: #100   value: 1           			refCount 1
# name         			address: #101   value: 2           			refCount 1
# name         			address: #102   value: 3           			refCount 1
# name   list_a        address: #103   value: [#100,#101,#102,#107] refCount 1
# name         			address: #104   value: 1           			refCount 0
# name         			address: #105   value: 2           			refCount 1
# name         			address: #106   value: 3           			refCount 1
# name   list_b        address: #107   value: [#108,#105,#106]      refCount 2
# name         			address: #108   value: 99           	    refCount 1


# a=4
# print (a)
# list_a=[1,a,5]
# print (list_a)
# a=6
# print (list_a)
# print (a)
# del list_a[0]
# del list_a


# name         address: #100   value: 4            refCount 0
# name          address: #101   value: 1            refCount 0
# name          address: #102   value: 5           refCount 0
# name     address: #103   value:                  refCount 0
# name  "a"     address: #104   value: 6            refCount 1

'''
list_a=[1,2,3]
list_b=[4,5,6]
#list_a.append(list_b.copy())  # Shallow Copy 1
#list_a.append(list(list_b))  # Shallow Copy 2
list_a.append(list_b[:])  # Shallow Copy 3
print (list_a)
list_b[0]=99
print (list_b)
print (list_a)
'''
# import copy
# list_a=[1,2,3]
# list_b=[4,5,6]
# list_c=[7,8,9]
# list_b.append(list_c)
# list_a.append(copy.deepcopy(list_b))
# print (list_a)
# list_b[0]=99
# list_c[0]=99
# print (list_a)

# from random import randint
# g1=randint(0,100)
# g2=randint(0,100)
# print (g1,g2)

# Task1:
# outcome1=[[23,45],[56,67].......100]
# outcome2=[1,0,1,0]
# Take the average
# convert to int
# check if its an even
#     1
#     0

# Task2:
# outcome1=[["sfdsf",32],["fsdfds",67].....100]


# from random import randint
# outcome1=[]
# outcome2=[]
# for x in range(100):
# 	a=randint(0,100)
# 	b=randint(0,100)
# 	outcome1.append([a,b])
# 	if(int((a+b)/2)%2==0):
# 		outcome2.append(1)
# 	else:
# 		outcome2.append(0)
# print (outcome1)
# print (outcome2)

# from random import randint
# outcome1=[]
# alpha="abcde"
# for x in range(100):
# 	a=""
# 	for y in range(6):
# 		a+=alpha[randint(0,len(alpha)-1)]
# 	b=randint(0,100)
# 	outcome1.append([a,b])
# print (outcome1)

# from random import randint
# outcome1=[]
# template=[0,0]
# for x in range(50):
# 	template[0]=randint(0,100)
# 	template[1]=randint(0,100)
# 	outcome1.append(template.copy())
# print (outcome1)

# from random import randint
# outcome1=[]
# for x in range(50):
# 	outcome1.append([randint(0,100),randint(0,100)])
# print (outcome1)

# from random import randint
# outcome1=[]
# for x in range(50):
# 	list_c=[randint(0,100),randint(0,100)] # Assignment
# 	outcome1.append(list_c)
# print (outcome1)


def clickme1():
	print ("Clicked1")

clickme1()

def clickme2(a,b=5):
	print ("Clicked2",a,b)
	
clickme2(4)

def clickme3():
	print ("Clicked2")
	return "Hello World"
	
a=clickme3()
print (a)


def clickme4():
	print ("Clicked4")

g=clickme4
print (clickme4)
print (g)
g()


def clickme5(a):
	print ("Clicked5",a)
	a()

def f1():
	print ("I AM F1")

clickme5(f1)



def clickme6():
	print ("Clicked6")
	return f1

def f1():
	print ("I AM F1")

g=clickme6()
print (g)
g()


# def f1():
# 	print ("Hello F11")
# h=f1
# def f1():
# 	print ("Hello F22")

# f1()
# f1()
# h()

def f1():
	print ('F1')

def f2():
	print ('F2')

def f3():
	print ('F3')

listMapper=[f1,f2,f3]
print (listMapper)
for x in listMapper:
	x()

listMapper=[f1(),f2(),f3()]
print (listMapper)






# Function
# list with function
# High Order Functions
# Multi Arguments