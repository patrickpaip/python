a=4
if(a==4):
    print ("Its 4")
    print ("Yes its 4")
print ("Hello World")
